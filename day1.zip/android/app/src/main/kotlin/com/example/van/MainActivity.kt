package com.example.van

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
